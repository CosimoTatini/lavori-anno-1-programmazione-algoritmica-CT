﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MassimoValore
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int maxValue = 2147483647;
            Console.WriteLine(maxValue);
            maxValue = maxValue + 1;
            Console.WriteLine(maxValue);
            Console.ReadLine();
              
        }
    }
}
