﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace areaCerchio
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Inserisci il raggio del cerchio");
            float r = float.Parse(Console.ReadLine());
            Console.ReadLine();

        }
    }
}
